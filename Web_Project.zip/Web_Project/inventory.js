const API_URL = '/api/inventory';

const inventoryTableBody = document.querySelector('#inventoryTable tbody');
const inventoryForm = document.getElementById('inventoryForm');
const resetBtn = document.getElementById('resetBtn');
const exportPdfBtn = document.getElementById('exportPdfBtn');

// Dark mode toggle
const darkModeBtn = document.createElement('button');
darkModeBtn.className = 'btn btn-outline-light ms-2';
darkModeBtn.innerHTML = '<i class="fas fa-moon"></i>';
darkModeBtn.title = 'Toggle dark mode';
document.querySelector('.navbar .container').appendChild(darkModeBtn);

darkModeBtn.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  if (document.body.classList.contains('dark-mode')) {
    darkModeBtn.innerHTML = '<i class="fas fa-sun"></i>';
    darkModeBtn.title = 'Switch to light mode';
  } else {
    darkModeBtn.innerHTML = '<i class="fas fa-moon"></i>';
    darkModeBtn.title = 'Switch to dark mode';
  }
});

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleString();
}

function clearForm() {
  inventoryForm.reset();
  document.getElementById('itemId').value = '';
  document.getElementById('image').value = '';
}

function fillForm(item) {
  document.getElementById('itemId').value = item._id;
  document.getElementById('name').value = item.name;
  document.getElementById('category').value = item.category || '';
  document.getElementById('supplier').value = item.supplier || '';
  document.getElementById('quantity').value = item.quantity;
  document.getElementById('price').value = item.price;
  document.getElementById('description').value = item.description || '';
  document.getElementById('image').value = '';
}

let allItems = [];
let lastCategories = [];

const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const supplierFilter = document.getElementById('supplierFilter');
const minPrice = document.getElementById('minPrice');
const maxPrice = document.getElementById('maxPrice');
const bulkImageBtn = document.getElementById('bulkImageBtn');

function renderCategoryOptions(items) {
  const categories = Array.from(new Set(items.map(i => i.category).filter(Boolean)));
  // Only update if categories changed
  if (JSON.stringify(categories) !== JSON.stringify(lastCategories)) {
    const current = categoryFilter.value;
    categoryFilter.innerHTML = '<option value="">All Categories</option>' +
      categories.map(cat => `<option value="${cat}">${cat}</option>`).join('');
    categoryFilter.value = current;
    lastCategories = categories;
  }
}

function renderSupplierOptions(items) {
  const suppliers = Array.from(new Set(items.map(i => i.supplier).filter(Boolean)));
  const current = supplierFilter.value;
  supplierFilter.innerHTML = '<option value="">All Suppliers</option>' +
    suppliers.map(sup => `<option value="${sup}">${sup}</option>`).join('');
  supplierFilter.value = current;
}

function renderInventory(items) {
  allItems = items;
  renderCategoryOptions(items);
  renderSupplierOptions(items);
  let filtered = items;
  const search = searchInput.value.trim().toLowerCase();
  const cat = categoryFilter.value;
  const sup = supplierFilter.value;
  const min = parseFloat(minPrice.value);
  const max = parseFloat(maxPrice.value);
  if (search) {
    filtered = filtered.filter(item =>
      item.name.toLowerCase().includes(search) ||
      (item.description && item.description.toLowerCase().includes(search))
    );
  }
  if (cat) {
    filtered = filtered.filter(item => item.category === cat);
  }
  if (sup) {
    filtered = filtered.filter(item => item.supplier === sup);
  }
  if (!isNaN(min)) {
    filtered = filtered.filter(item => item.price >= min);
  }
  if (!isNaN(max)) {
    filtered = filtered.filter(item => item.price <= max);
  }
  document.getElementById('itemCount').textContent = `${filtered.length} item${filtered.length !== 1 ? 's' : ''}`;
  inventoryTableBody.innerHTML = '';
  filtered.forEach(item => {
    const imgSrc = item.image || "https://cdn-icons-png.flaticon.com/512/1046/1046857.png";
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><img src="${imgSrc}" alt="item" class="item-img rounded" width="48" height="48"></td>
      <td>${item.name}</td>
      <td><span class="badge bg-info text-dark">${item.category || ''}</span></td>
      <td>${item.supplier || ''}</td>
      <td><span class="fw-bold text-success">${item.quantity}</span></td>
      <td><span class="fw-bold text-primary">${item.price}</span></td>
      <td>${item.description || ''}</td>
      <td>${formatDate(item.dateAdded)}</td>
      <td>${formatDate(item.lastUpdated)}</td>
      <td>
        <button class="btn btn-sm btn-info me-1" onclick='editItem("${item._id}")'><i class="fas fa-edit"></i></button>
        <button class="btn btn-sm btn-danger" onclick='deleteItem("${item._id}")'><i class="fas fa-trash-alt"></i></button>
      </td>
    `;
    inventoryTableBody.appendChild(tr);
  });
}

async function fetchInventory() {
  try {
    const res = await fetch(API_URL);
    if (!res.ok) throw new Error('Failed to fetch inventory');
    const items = await res.json();
    renderInventory(items);
  } catch (err) {
    alert('Error fetching inventory: ' + err.message);
    console.error(err);
  }
}

window.editItem = async function(id) {
  const res = await fetch(`${API_URL}/${id}`);
  const item = await res.json();
  fillForm(item);
  // Store the current image in a data attribute for later use
  document.getElementById('image').setAttribute('data-old-image', item.image || '');
}

window.deleteItem = async function(id) {
  if (!confirm('Are you sure you want to delete this item?')) return;
  await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
  fetchInventory();
}

inventoryForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const itemId = document.getElementById('itemId').value;
  const item = {
    name: document.getElementById('name').value,
    category: document.getElementById('category').value,
    supplier: document.getElementById('supplier').value,
    quantity: Number(document.getElementById('quantity').value),
    price: Number(document.getElementById('price').value),
    description: document.getElementById('description').value
  };
  const imageInput = document.getElementById('image');
  const oldImage = imageInput.getAttribute('data-old-image') || '';
  // Always handle image as async, always send image field
  if (imageInput.files && imageInput.files[0]) {
    const file = imageInput.files[0];
    const reader = new FileReader();
    reader.onload = async function(evt) {
      item.image = evt.target.result || '';
      await submitItem(itemId, item);
    };
    reader.onerror = function() {
      alert('Error reading image file.');
      item.image = '';
      submitItem(itemId, item);
    };
    reader.readAsDataURL(file);
  } else {
    // For new item, image is empty string; for edit, use old image if present
    item.image = itemId && oldImage ? oldImage : '';
    await submitItem(itemId, item);
  }
});

resetBtn.addEventListener('click', clearForm);

exportPdfBtn.addEventListener('click', function() {
  window.open('/api/inventory/export/pdf', '_blank');
});

searchInput.addEventListener('input', () => renderInventory(allItems));
categoryFilter.addEventListener('change', () => renderInventory(allItems));
supplierFilter.addEventListener('change', () => renderInventory(allItems));
minPrice.addEventListener('input', () => renderInventory(allItems));
maxPrice.addEventListener('input', () => renderInventory(allItems));
bulkImageBtn.addEventListener('click', () => {
  alert('Bulk image update coming soon!');
});

async function submitItem(itemId, item) {
  try {
    let res;
    if (itemId) {
      res = await fetch(`${API_URL}/${itemId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(item)
      });
    } else {
      res = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(item)
      });
    }
    if (!res.ok) {
      const errData = await res.json();
      alert('Error saving item: ' + (errData.message || res.statusText));
      return;
    }
    alert('Item saved successfully!');
    clearForm();
    fetchInventory();
  } catch (err) {
    alert('Error saving item: ' + err.message);
    console.error(err);
  }
}

// Initial load
fetchInventory(); 