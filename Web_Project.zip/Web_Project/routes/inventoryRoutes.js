const express = require('express');
const router = express.Router();
const InventoryItem = require('../models/inventoryItem');
const PDFDocument = require('pdfkit');

// Get all inventory items
router.get('/', async (req, res) => {
  try {
    const items = await InventoryItem.find();
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get one inventory item by ID
router.get('/:id', async (req, res) => {
  try {
    const item = await InventoryItem.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    res.json(item);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Create a new inventory item
router.post('/', async (req, res) => {
  const item = new InventoryItem({
    name: req.body.name,
    description: req.body.description,
    quantity: req.body.quantity,
    price: req.body.price,
    category: req.body.category,
    supplier: req.body.supplier,
    image: req.body.image,
    totalSales: req.body.totalSales || 0,
    lastSold: req.body.lastSold || null
  });
  try {
    const newItem = await item.save();
    res.status(201).json(newItem);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Update an inventory item
router.put('/:id', async (req, res) => {
  try {
    const item = await InventoryItem.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    item.name = req.body.name ?? item.name;
    item.description = req.body.description ?? item.description;
    item.quantity = req.body.quantity ?? item.quantity;
    item.price = req.body.price ?? item.price;
    item.category = req.body.category ?? item.category;
    item.supplier = req.body.supplier ?? item.supplier;
    if (req.body.image !== undefined) item.image = req.body.image;
    if (req.body.totalSales !== undefined) item.totalSales = req.body.totalSales;
    if (req.body.lastSold !== undefined) item.lastSold = req.body.lastSold;
    item.lastUpdated = Date.now();
    const updatedItem = await item.save();
    res.json(updatedItem);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete an inventory item
router.delete('/:id', async (req, res) => {
  try {
    const item = await InventoryItem.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    res.json({ message: 'Item deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Export inventory as PDF
router.get('/export/pdf', async (req, res) => {
  try {
    const items = await InventoryItem.find();
    const doc = new PDFDocument({ margin: 30, size: 'A4', layout: 'landscape' });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="inventory_report.pdf"');
    doc.pipe(res);
    // Shop logo
    const logoUrl = 'https://cdn-icons-png.flaticon.com/512/1046/1046857.png';
    try {
      const https = require('https');
      const url = require('url');
      const logoBuffer = await new Promise((resolve, reject) => {
        https.get(url.parse(logoUrl), (resp) => {
          const data = [];
          resp.on('data', chunk => data.push(chunk));
          resp.on('end', () => resolve(Buffer.concat(data)));
        }).on('error', reject);
      });
      doc.image(logoBuffer, 30, 20, { width: 48, height: 48 });
    } catch (e) {}
    doc.fontSize(22).fillColor('#007bff').text('Inventory Report', 90, 30, { align: 'left', underline: true });
    doc.moveDown(2.5);
    // Summary stats
    const totalItems = items.length;
    const totalQty = items.reduce((sum, i) => sum + (i.quantity || 0), 0);
    const totalValue = items.reduce((sum, i) => sum + ((i.quantity || 0) * (i.price || 0)), 0);
    doc.fontSize(12).fillColor('#333').text(`Total Items: ${totalItems}`, 90, 60);
    doc.text(`Total Quantity: ${totalQty}`, 200, 60);
    doc.text(`Total Value: Rs. ${totalValue.toLocaleString()}`, 350, 60);
    doc.moveDown(2);
    // Table header
    const startY = doc.y;
    const col = [32, 90, 180, 270, 340, 410, 480, 650, 770];
    doc.fontSize(12).fillColor('#fff').rect(30, startY, 850, 24).fill('#007bff');
    doc.fillColor('#fff').font('Helvetica-Bold');
    doc.text('Image', col[0], startY + 6, { width: 50, align: 'center' });
    doc.text('Name', col[1], startY + 6, { width: 90, align: 'center' });
    doc.text('Category', col[2], startY + 6, { width: 90, align: 'center' });
    doc.text('Supplier', col[3], startY + 6, { width: 70, align: 'center' });
    doc.text('Qty', col[4], startY + 6, { width: 50, align: 'center' });
    doc.text('Price', col[5], startY + 6, { width: 50, align: 'center' });
    doc.text('Description', col[6], startY + 6, { width: 170, align: 'center' });
    doc.text('Added', col[7], startY + 6, { width: 100, align: 'center' });
    doc.text('Updated', col[8], startY + 6, { width: 100, align: 'center' });
    doc.moveDown();
    let y = startY + 24;
    // Table rows
    items.forEach((item, idx) => {
      if (idx % 2 === 0) {
        doc.rect(30, y, 850, 32).fill('#f8f9fa');
      } else {
        doc.rect(30, y, 850, 32).fill('#e3f2fd');
      }
      doc.fillColor('#000').font('Helvetica').fontSize(10);
      // Image
      if (item.image && item.image.startsWith('data:image')) {
        try {
          const base64Data = item.image.split(',')[1];
          const imgBuffer = Buffer.from(base64Data, 'base64');
          doc.image(imgBuffer, col[0], y + 2, { width: 28, height: 28 });
        } catch (e) {
          doc.text('N/A', col[0], y + 10, { width: 50, align: 'center' });
        }
      } else {
        doc.text('N/A', col[0], y + 10, { width: 50, align: 'center' });
      }
      doc.text(item.name, col[1], y + 10, { width: 90, align: 'center' });
      doc.text(item.category || '', col[2], y + 10, { width: 90, align: 'center' });
      doc.text(item.supplier || '', col[3], y + 10, { width: 70, align: 'center' });
      doc.text(item.quantity?.toString() || '', col[4], y + 10, { width: 50, align: 'center' });
      doc.text(item.price?.toString() || '', col[5], y + 10, { width: 50, align: 'center' });
      // Truncate description if too long
      let desc = item.description || '';
      if (desc.length > 50) desc = desc.slice(0, 47) + '...';
      doc.text(desc, col[6], y + 10, { width: 170, align: 'center' });
      doc.text(item.dateAdded ? new Date(item.dateAdded).toLocaleDateString() : '', col[7], y + 10, { width: 100, align: 'center' });
      doc.text(item.lastUpdated ? new Date(item.lastUpdated).toLocaleDateString() : '', col[8], y + 10, { width: 100, align: 'center' });
      doc.rect(30, y, 850, 32).stroke('#007bff');
      y += 32;
      if (y > 550) {
        doc.addPage({ size: 'A4', layout: 'landscape' });
        y = 30;
      }
    });
    doc.end();
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router; 